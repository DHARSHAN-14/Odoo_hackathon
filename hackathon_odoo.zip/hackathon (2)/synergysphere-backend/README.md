
# SynergySphere Backend (Express + PostgreSQL)

MVP backend for projects, groups, chat (messages + mentions), todos, and notifications.

## Quick Start

1) Create database and set environment variables.

Copy `.env.example` to `.env` and edit:
```
PORT=8080
DATABASE_URL=postgres://postgres:postgres@localhost:5432/synergysphere
JWT_SECRET=supersecret_change_me
CORS_ORIGIN=http://localhost:5173
```
2) Run migration:
```
npm install
npm run migrate
```

3) Start server:
```
npm run dev
```

## Test accounts

Use `/api/auth/register` to create users.

## API Base

All endpoints are prefixed with `/api`.

- Auth: `/api/auth/register`, `/api/auth/login`, `/api/auth/me`
- Projects: `/api/projects` (GET/POST)
- Join Requests: `/api/projects/:id/join-requests` (POST), `/api/projects/:id/approve` (POST)
- Groups: `/api/projects/:id/groups` (GET)
- Messages: `/api/groups/:groupId/messages` (GET/POST)
- Mentions: `/api/mentions` (GET)
- Todos: `/api/todos` (GET/POST/PUT/DELETE)
- Notifications: `/api/notifications` (GET/PUT :id/read)
- Users: `/api/users/search?q=alice`

