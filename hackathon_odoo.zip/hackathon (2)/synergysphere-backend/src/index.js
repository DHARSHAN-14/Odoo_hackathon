
import express from 'express';
import 'dotenv/config';
import helmet from 'helmet';
import cors from 'cors';
import morgan from 'morgan';
import rateLimit from 'express-rate-limit';
import { pool } from './db.js';
import authRoutes from './routes/auth.js';
import projectRoutes from './routes/projects.js';
import groupRoutes from './routes/groups.js';
import messageRoutes from './routes/messages.js';
import todoRoutes from './routes/todos.js';
import mentionRoutes from './routes/mentions.js';
import notificationRoutes from './routes/notifications.js';
import userRoutes from './routes/users.js';
import { notFound, errorHandler } from './middleware/error.js';

const app = express();

const corsOrigin = process.env.CORS_ORIGIN || '*';
app.use(cors({ origin: corsOrigin, credentials: true }));
app.use(helmet());
app.use(express.json({ limit: '1mb' }));
app.use(morgan('dev'));

const limiter = rateLimit({ windowMs: 60 * 1000, max: 120 });
app.use(limiter);

app.get('/api/health', async (req, res) => {
  const r = await pool.query('SELECT 1');
  res.json({ ok: true, db: r.rows[0]['?column?'] === 1 });
});

app.use('/api/auth', authRoutes);
app.use('/api/projects', projectRoutes);
app.use('/api/projects', groupRoutes); // groups under project
app.use('/api/groups', messageRoutes); // messages
app.use('/api/todos', todoRoutes);
app.use('/api/mentions', mentionRoutes);
app.use('/api/notifications', notificationRoutes);
app.use('/api/users', userRoutes);

app.use(notFound);
app.use(errorHandler);

const port = process.env.PORT || 8080;
app.listen(port, () => console.log(`API running on :${port}`));
