
/* This file is kept minimal because group creation is handled via project approval. */
export default (req, res, next) => next();
