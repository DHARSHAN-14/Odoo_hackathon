
import express from 'express';
import { pool } from '../db.js';
import { requireAuth } from '../middleware/auth.js';

const router = express.Router();

router.get('/', requireAuth, async (req, res, next) => {
  try {
    const r = await pool.query(`
      SELECT m.id as mention_id, msg.id as message_id, msg.text, msg.group_id, msg.created_at
      FROM mentions m
      JOIN messages msg ON msg.id = m.message_id
      WHERE m.mentioned_user_id=$1
      ORDER BY msg.created_at DESC
      LIMIT 100
    `, [req.user.id]);
    res.json(r.rows);
  } catch (e) { next(e); }
});

export default router;
