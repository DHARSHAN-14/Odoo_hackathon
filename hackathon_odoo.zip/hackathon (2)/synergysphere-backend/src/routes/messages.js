
import express from 'express';
import { pool } from '../db.js';
import { requireAuth } from '../middleware/auth.js';

const router = express.Router();

// List messages in group (cursor pagination by id)
router.get('/:groupId/messages', requireAuth, async (req, res, next) => {
  try {
    const group_id = Number(req.params.groupId);
    const { afterId } = req.query;

    // Ensure user is in this group via project membership check
    const pr = await pool.query(`SELECT g.project_id
      FROM groups g
      JOIN project_members pm ON pm.project_id = g.project_id
      WHERE g.id=$1 AND pm.user_id=$2`, [group_id, req.user.id]);
    if (!pr.rowCount) return res.status(403).json({ error: 'No access to group' });

    const r = await pool.query(`
      SELECT m.id, m.text, m.author_id, u.name as author_name, m.created_at
      FROM messages m
      JOIN users u ON u.id = m.author_id
      WHERE m.group_id=$1 AND ($2::int IS NULL OR m.id > $2::int)
      ORDER BY m.id ASC
      LIMIT 100
    `, [group_id, afterId || null]);
    res.json(r.rows);
  } catch (e) { next(e); }
});

// Post message. Mentions format: use @<userId> in text, we'll detect digits after '@'.
router.post('/:groupId/messages', requireAuth, async (req, res, next) => {
  try {
    const group_id = Number(req.params.groupId);
    const { text } = req.body;
    if (!text || !text.trim()) return res.status(400).json({ error: 'Empty message' });

    // Ensure membership
    const pr = await pool.query(`SELECT g.project_id
      FROM groups g
      JOIN project_members pm ON pm.project_id = g.project_id
      WHERE g.id=$1 AND pm.user_id=$2`, [group_id, req.user.id]);
    if (!pr.rowCount) return res.status(403).json({ error: 'No access to group' });
    const project_id = pr.rows[0].project_id;

    await pool.query('BEGIN');
    const ins = await pool.query(`
      INSERT INTO messages (project_id, group_id, author_id, text)
      VALUES ($1,$2,$3,$4) RETURNING id, created_at
    `, [project_id, group_id, req.user.id, text]);
    const messageId = ins.rows[0].id;

    // Detect mentions like @123 (user id)
    const mentioned = Array.from(text.matchAll(/@(\d+)/g)).map(m => Number(m[1]));
    for (const userId of mentioned) {
      await pool.query(`INSERT INTO mentions (message_id, mentioned_user_id) VALUES ($1,$2)`, [messageId, userId]);
      // create notification
      await pool.query(`INSERT INTO notifications (user_id, type, payload) VALUES ($1,'mention', jsonb_build_object('messageId',$2,'groupId',$3))`, [userId, messageId, group_id]);
    }
    await pool.query('COMMIT');

    res.status(201).json({ id: messageId, created_at: ins.rows[0].created_at });
  } catch (e) {
    await pool.query('ROLLBACK');
    next(e);
  }
});

export default router;
