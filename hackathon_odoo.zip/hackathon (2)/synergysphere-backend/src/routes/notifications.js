
import express from 'express';
import { pool } from '../db.js';
import { requireAuth } from '../middleware/auth.js';

const router = express.Router();

router.get('/', requireAuth, async (req, res, next) => {
  try {
    const r = await pool.query(`
      SELECT id, type, payload, is_read, created_at
      FROM notifications
      WHERE user_id=$1
      ORDER BY created_at DESC
      LIMIT 100
    `, [req.user.id]);
    res.json(r.rows);
  } catch (e) { next(e); }
});

router.put('/:id/read', requireAuth, async (req, res, next) => {
  try {
    const id = Number(req.params.id);
    await pool.query('UPDATE notifications SET is_read=true WHERE id=$1 AND user_id=$2', [id, req.user.id]);
    res.json({ ok: true });
  } catch (e) { next(e); }
});

export default router;
