
import express from 'express';
import { pool } from '../db.js';
import { requireAuth } from '../middleware/auth.js';

const router = express.Router();

// List projects for current user
router.get('/', requireAuth, async (req, res, next) => {
  try {
    const q = await pool.query(`
      SELECT p.id, p.name, p.description, p.owner_id, p.created_at
      FROM projects p
      JOIN project_members pm ON pm.project_id = p.id
      WHERE pm.user_id = $1
      ORDER BY p.created_at DESC
    `, [req.user.id]);
    res.json(q.rows);
  } catch (e) { next(e); }
});

// Create project (creator becomes admin). Also create MAIN group.
router.post('/', requireAuth, async (req, res, next) => {
  try {
    const { name, description, start_date, end_date } = req.body;
    await pool.query('BEGIN');
    const pr = await pool.query(`
      INSERT INTO projects (name, description, owner_id, start_date, end_date)
      VALUES ($1,$2,$3,$4,$5) RETURNING id, name, description, owner_id
    `, [name, description || '', req.user.id, start_date || null, end_date || null]);
    const project = pr.rows[0];

    await pool.query(`
      INSERT INTO project_members (project_id, user_id, role, is_admin)
      VALUES ($1,$2,$3,$4)
    `, [project.id, req.user.id, 'lead', true]);

    const gr = await pool.query(`
      INSERT INTO groups (project_id, name, is_main) VALUES ($1,'Main', true) RETURNING id, name, is_main
    `, [project.id]);
    await pool.query('COMMIT');
    res.status(201).json({ project, mainGroup: gr.rows[0] });
  } catch (e) {
    await pool.query('ROLLBACK');
    next(e);
  }
});

// Join request to a project with desired role
router.post('/:id/join-requests', requireAuth, async (req, res, next) => {
  try {
    const { role } = req.body;
    const project_id = Number(req.params.id);
    const exists = await pool.query(`SELECT id FROM join_requests WHERE project_id=$1 AND user_id=$2 AND status='pending'`,
      [project_id, req.user.id]);
    if (exists.rowCount) return res.status(409).json({ error: 'Already requested' });
    const r = await pool.query(`
      INSERT INTO join_requests (project_id, user_id, role, status) VALUES ($1,$2,$3,'pending')
      RETURNING id, project_id, user_id, role, status, created_at
    `, [project_id, role || 'member']);
    res.status(201).json(r.rows[0]);
  } catch (e) { next(e); }
});

// Approve or reject a user (admin only)
router.post('/:id/approve', requireAuth, async (req, res, next) => {
  try {
    const project_id = Number(req.params.id);
    const { userId, role, approve } = req.body;

    // Verify current user is admin
    const adm = await pool.query(`SELECT is_admin FROM project_members WHERE project_id=$1 AND user_id=$2`, [project_id, req.user.id]);
    if (!adm.rowCount || !adm.rows[0].is_admin) return res.status(403).json({ error: 'Admin only' });

    if (!approve) {
      await pool.query(`UPDATE join_requests SET status='rejected' WHERE project_id=$1 AND user_id=$2`, [project_id, userId]);
      return res.json({ ok: true, status: 'rejected' });
    }

    await pool.query('BEGIN');
    // Mark request as approved
    await pool.query(`UPDATE join_requests SET status='approved' WHERE project_id=$1 AND user_id=$2`, [project_id, userId]);
    // Upsert membership
    await pool.query(`
      INSERT INTO project_members (project_id, user_id, role, is_admin)
      VALUES ($1,$2,$3,false)
      ON CONFLICT (project_id, user_id) DO UPDATE SET role=EXCLUDED.role
    `, [project_id, userId, role || 'member']);
    // Ensure subgroup with role exists
    const g = await pool.query(`
      SELECT id FROM groups WHERE project_id=$1 AND LOWER(name)=LOWER($2)
    `, [project_id, role || 'member']);
    let groupId;
    if (g.rowCount) {
      groupId = g.rows[0].id;
    } else {
      const ng = await pool.query(`INSERT INTO groups (project_id, name, is_main) VALUES ($1,$2,false) RETURNING id`, [project_id, role || 'member']);
      groupId = ng.rows[0].id;
    }
    // Add to group_members
    await pool.query(`
      INSERT INTO group_members (group_id, user_id) VALUES ($1,$2) ON CONFLICT DO NOTHING
    `, [groupId, userId]);
    await pool.query('COMMIT');
    res.json({ ok: true, groupId });
  } catch (e) {
    await pool.query('ROLLBACK');
    next(e);
  }
});

// List groups for a project (must be member)
router.get('/:id/groups', requireAuth, async (req, res, next) => {
  try {
    const project_id = Number(req.params.id);
    const mem = await pool.query(`SELECT 1 FROM project_members WHERE project_id=$1 AND user_id=$2`, [project_id, req.user.id]);
    if (!mem.rowCount) return res.status(403).json({ error: 'Join project first' });
    const r = await pool.query(`SELECT id, name, is_main FROM groups WHERE project_id=$1 ORDER BY is_main DESC, name ASC`, [project_id]);
    res.json(r.rows);
  } catch (e) { next(e); }
});

export default router;
