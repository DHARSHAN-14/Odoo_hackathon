
import express from 'express';
import { pool } from '../db.js';
import { requireAuth } from '../middleware/auth.js';

const router = express.Router();

router.get('/', requireAuth, async (req, res, next) => {
  try {
    const { type } = req.query; // 'today' | 'calendar' | undefined
    const r = await pool.query(`
      SELECT id, title, description, due_at, type, is_done, created_at
      FROM todos
      WHERE user_id=$1 AND ($2::text IS NULL OR type=$2::text)
      ORDER BY (due_at IS NULL), due_at ASC, created_at DESC
    `, [req.user.id, type || null]);
    res.json(r.rows);
  } catch (e) { next(e); }
});

router.post('/', requireAuth, async (req, res, next) => {
  try {
    const { title, description, due_at, type } = req.body; // type: 'today' | 'calendar'
    const r = await pool.query(`
      INSERT INTO todos (user_id, title, description, due_at, type)
      VALUES ($1,$2,$3,$4,$5)
      RETURNING id, title, description, due_at, type, is_done, created_at
    `, [req.user.id, title, description || '', due_at || null, type || 'today']);
    res.status(201).json(r.rows[0]);
  } catch (e) { next(e); }
});

router.put('/:id', requireAuth, async (req, res, next) => {
  try {
    const id = Number(req.params.id);
    const { title, description, due_at, is_done } = req.body;
    const r = await pool.query(`
      UPDATE todos SET
        title = COALESCE($1, title),
        description = COALESCE($2, description),
        due_at = COALESCE($3, due_at),
        is_done = COALESCE($4, is_done)
      WHERE id=$5 AND user_id=$6
      RETURNING id, title, description, due_at, type, is_done, created_at
    `, [title, description, due_at, is_done, id, req.user.id]);
    if (!r.rowCount) return res.status(404).json({ error: 'Not found' });
    res.json(r.rows[0]);
  } catch (e) { next(e); }
});

router.delete('/:id', requireAuth, async (req, res, next) => {
  try {
    const id = Number(req.params.id);
    const r = await pool.query(`DELETE FROM todos WHERE id=$1 AND user_id=$2`, [id, req.user.id]);
    res.json({ ok: r.rowCount > 0 });
  } catch (e) { next(e); }
});

export default router;
