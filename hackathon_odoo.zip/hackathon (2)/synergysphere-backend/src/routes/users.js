
import express from 'express';
import { pool } from '../db.js';
import { requireAuth } from '../middleware/auth.js';

const router = express.Router();

router.get('/search', requireAuth, async (req, res, next) => {
  try {
    const q = (req.query.q || '').toLowerCase();
    const r = await pool.query(`
      SELECT id, name, email FROM users
      WHERE LOWER(name) LIKE '%' || $1 || '%' OR LOWER(email) LIKE '%' || $1 || '%'
      ORDER BY name ASC
      LIMIT 20
    `, [q]);
    res.json(r.rows);
  } catch (e) { next(e); }
});

export default router;
